// Navigation functionality
    function showSection(sectionId) {
      // Hide all sections
      document.querySelectorAll('section').forEach(section => {
        section.classList.remove('active');
      });
      
      // Show selected section
      const section = document.getElementById(sectionId);
      if (section) {
        section.classList.add('active');
      }
      
      // Update active nav link
      document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('onclick')?.includes(sectionId)) {
          link.classList.add('active');
        }
      });
      
      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Form handling
    document.getElementById('reportForm')?.addEventListener('submit', function(e) {
      e.preventDefault();
      document.getElementById('successMessage').style.display = 'block';
      this.reset();
      setTimeout(() => {
        document.getElementById('successMessage').style.display = 'none';
      }, 5000);
    });

    document.getElementById('contactForm')?.addEventListener('submit', function(e) {
      e.preventDefault();
      alert('Thank you for your message! We will respond soon.');
      this.reset();
    });

    // Initialize with home section active
    document.addEventListener('DOMContentLoaded', function() {
      showSection('home');
    });