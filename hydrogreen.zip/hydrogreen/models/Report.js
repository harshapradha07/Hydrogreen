const mongoose = require('mongoose');

const reportSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  location: String,
  problemType: String,
  description: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Report', reportSchema);
